

<?php $__env->startSection('title'); ?>
  Edit Profile
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

   <div class="container">
     <div class="row">
       <div class="col-lg-6 m-auto">
         <div class="card">
           <div class="card-header">

               <h5 class="text-center">Change Password</h5>
             </div>
             
             <?php if($errors->all()): ?>
               <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>

             <?php endif; ?>
             <?php if(session('success')): ?>
               <div class="alert alert-success">
                 <?php echo e(session('success')); ?>

               </div>
             <?php endif; ?>
             <div class="card-body">
               <form class="form-group" action="<?php echo e(route('passwordpost')); ?>" method="post">
                 <?php echo csrf_field(); ?>
                 <div class="py-3">
                   <input class="form-control" type="password" name="old_password" placeholder="Enter Old Password">
                   
                 </div>
                 <div class="py-3">
                   <input class="form-control" type="password" name="password" placeholder="Enter New Password">
                 </div>
                 <div class="py-3">
                   <input class="form-control" type="password" name="password_confirmation" placeholder="Confirm Password">
                 </div>
                 <div class="py-3">
                   <button type="submit" class="btn btn-primary">Change Password</button>
                 </div>

               </form>
             </div>

         </div>
       </div>
     </div>
   </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\water\resources\views/admin/edit.blade.php ENDPATH**/ ?>