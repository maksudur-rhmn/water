

<?php $__env->startSection('title'); ?>
  Frequently Asked Questions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-faq'); ?>
  active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav'); ?>
  <nav class="breadcrumb sl-breadcrumb">
    <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>">Home</a>
    
    <span class="breadcrumb-item active">Faq</span>
  </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



        <div class="container">
          <div class="row">
            <div class="col-lg-8">
              <div class="card">
               <div class="card-header">
                  <h1 class="text-center">All FAQ !!!</h1>
               </div>
               <div class="card-body">
                 <?php if(session('status')): ?>
                 <div class="alert alert-success">
                   <?php echo e(session('status')); ?>

                 </div>
               <?php endif; ?>
               <?php if(session('success')): ?>
                 <div class="alert alert-success">
                   <?php echo e(session('success')); ?>

                 </div>
               <?php endif; ?>
                 <table class="table table-dark table-striped">
                    <tr>
                      <th>SL NO.</th>
                      <th>Question</th>
                      <th>Answer</th>
                      <th>Action</th>
                    </tr>
                    <?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <th><?php echo e($loop-> index + 1); ?></th>
                      <th><?php echo e($faq->faq_question); ?></th>
                      <th><?php echo e($faq->faq_answer); ?></th>
                      <th>
                        <div class="btn-group">
                          <a href="<?php echo e(url('/faq/edit')); ?>/<?php echo e($faq->id); ?>" class="btn btn-primary btn-sm">Edit</a>
                          <a href="<?php echo e(url('/faq/delete')); ?>/<?php echo e($faq->id); ?>" class="btn btn-danger btn-sm">Delete</a>
                        </div>
                      </th>
                    </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                       <tr>
                         <td>No data Available</td>
                       </tr>

                    <?php endif; ?>
                 </table>



               </div>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="card">
                <?php if($errors->all()): ?>
                     <div class="alert alert-danger">
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>
              <?php endif; ?>
                <div class="card-header">
                  Add FAQ
                </div>
                <div class="card-body">
                  <form class="form-group" action="<?php echo e(route('faq_insert')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                  <div class="py-3">
                    <label for="question">Enter Question</label>
                    <input name="faq_question" class="form-control" id="question" type="text" name="" placeholder="Enter Your Question?" value="<?php echo e(old('faq_question')); ?>">
                    <?php $__errorArgs = ['faq_question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                  </div>
                    <label for="answer">Enter Answer</label>
                    <textarea name="faq_answer" id="answer" class="form-control" name="" placeholder="Enter Your Answer"><?php echo e(old('faq_answer')); ?></textarea>
                    <?php $__errorArgs = ['faq_answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <div class="py-3">
                      <button type="submit" class="btn btn-success">Submit</button>
                  </div>
                  </form>
                </div>
              </div>
            </div>
            <div class="col-lg-8">
              <div class="card">
               <div class="card-header">
                  <h1 class="text-center">Deleted FAQ !!!</h1>
               </div>
               <div class="card-body">

                 <table class="table table-dark table-striped">
                    <tr>
                      <th>SL NO.</th>
                      <th>Question</th>
                      <th>Answer</th>
                      <th>Deleted at</th>
                      <th>Action</th>
                    </tr>

                    <?php $__empty_1 = true; $__currentLoopData = $deleted_faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deleted): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th><?php echo e($loop -> index +1); ?></th>
                        <th><?php echo e($deleted->faq_question); ?></th>
                        <th><?php echo e($deleted->faq_answer); ?></th>
                        <th><?php echo e($deleted->deleted_at->diffForHumans()); ?></th>
                        <th>
                          <div class="btn-group">
                            <a href="<?php echo e(url('/faq/restore')); ?>/<?php echo e($deleted->id); ?>" class="btn btn-primary btn-sm">Restore</a>
                            <a href="<?php echo e(url('/faq/permanentDelete')); ?>/<?php echo e($deleted->id); ?>" class="btn btn-danger btn-sm">permanentDelete</a>
                          </div>
                        </th>

                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>

                      <th>No data</th>
                    </tr>
                  <?php endif; ?>

                 </table>



               </div>
              </div>
            </div>
          </div>

        </div>











<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\water\resources\views/faq/index.blade.php ENDPATH**/ ?>