<?php $__env->startSection('title'); ?>
  Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-home'); ?>
  active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav'); ?>
  <nav class="breadcrumb sl-breadcrumb">
    <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>">Home</a>
    
  </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
          <div class="card">
            <div class="card-header">
               <h1 class="text-center">All Orders !!!</h1>
            </div>
            <div class="card-body">
              <?php if(session('status')): ?>
              <div class="alert alert-success">
                <?php echo e(session('status')); ?>

              </div>
            <?php endif; ?>
            <?php if(session('success')): ?>
              <div class="alert alert-success">
                <?php echo e(session('success')); ?>

              </div>
            <?php endif; ?>
              <table class="table table-dark table-striped">
                 <tr>
                   <th>SL NO.</th>
                   <th>Order Number</th>
                   <th>email</th>
                   <th><i class="fa fa-phone" aria-hidden="true"></i></th>
                   <th>Action</th>
                 </tr>
                 <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                 <tr>
                   <th><?php echo e($loop-> index + 1); ?></th>
                   <th><?php echo e($order->id); ?></th>
                   <th><?php echo e($order->email); ?></th>
                   <th><?php echo e($order->phone_number); ?></th>
                   <th>
                     <div class="btn-group">
                       <a href="<?php echo e(route('download.pdf', $order->id)); ?>" class="btn btn-primary btn-sm">Download</a>
                       <a href="<?php echo e(route('send.text', $order->id)); ?>" class="btn btn-danger btn-sm">Send Text message</a>
                     </div>
                   </th>
                 </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <td>No data Available</td>
                    </tr>

                 <?php endif; ?>
              </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\Test Projects\water\resources\views/customer/index.blade.php ENDPATH**/ ?>