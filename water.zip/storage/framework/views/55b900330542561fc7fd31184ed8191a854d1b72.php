
<?php $__env->startSection('title'); ?>
  Coupon
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-coupon'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav'); ?>
  <nav class="breadcrumb sl-breadcrumb">
    <a class="breadcrumb-item" href="<?php echo e(route('coupon.index')); ?>">Coupons</a>
    <span class="breadcrumb-item active">Add Coupon</span>
  </nav>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-lg-8 m-auto">
        <?php if(session('success')): ?>
          <div class="alert alert-success" role="alert">
              <?php echo e(session('success')); ?>

          </div>
        <?php endif; ?>
        <?php if($errors->all()): ?>
          <div class="alert alert-danger" role="alert">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($element); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
        <div class="card">
          <div class="card-header">
            <h1 class="text-center"><?php echo e(isset($coupon) ? 'Edit Coupon' : 'Add Coupon'); ?></h1>
          </div>
          <div class="card-body">
            <form class="form-group" action="<?php echo e(isset($coupon) ? route('coupon.update', $coupon->id) : route('coupon.store')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php if(isset($coupon)): ?>
                <?php echo e(method_field('PUT')); ?>

              <?php endif; ?>
                <div class="py-3">
                  <input class="form-control" type="text" name="coupon_name" value="<?php echo e(isset($coupon) ? $coupon->coupon_name : ''); ?>" placeholder="Coupon Name">
                </div>
                <div class="py-3">
                  <input class="form-control" type="number" name="discount" value="<?php echo e(isset($coupon) ? $coupon->discount : ''); ?>" placeholder="Discount">
                </div>
                <div class="py-3">
                  <input type="date" name="valid_till" value="<?php echo e(isset($coupon) ? $coupon->valid_till : ''); ?>" class="form-control" min=<?php echo e(\Carbon\Carbon::now()->toDateString()); ?>>
                </div>
                <div class="py-3">
                  <button type="submit" class="btn btn-primary"><?php echo e(isset($coupon) ? 'Update Coupon' : 'Add Coupon'); ?></button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\Test Projects\water\resources\views/coupon/create.blade.php ENDPATH**/ ?>