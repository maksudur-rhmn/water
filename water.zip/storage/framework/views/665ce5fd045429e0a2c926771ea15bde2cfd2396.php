

<?php $__env->startSection('title'); ?>
  Water - Ecommerce Shop
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- .breadcumb-area start -->
     <div class="breadcumb-area bg-img-4 ptb-100">
         <div class="container">
             <div class="row">
                 <div class="col-12">
                     <div class="breadcumb-wrap text-center">
                         <h2>Shop Page</h2>
                         <ul>
                             <li><a href="index.html">Home</a></li>
                             <li><span>Shop</span></li>
                         </ul>
                     </div>
                 </div>
             </div>
         </div>
     </div>
     <!-- .breadcumb-area end -->
     <!-- product-area start -->
     <div class="product-area pt-100">
         <div class="container">
             <div class="row">
                 <div class="col-sm-12 col-lg-12">
                     <div class="product-menu">
                         <ul class="nav justify-content-center">
                             <li>
                                 <a class="active" data-toggle="tab" href="#all">All product</a>
                             </li>
                             <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <li>
                                 <a data-toggle="tab" href="#category_<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></a>
                               </li>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </ul>
                     </div>
                 </div>
             </div>
             <div class="tab-content">
                 <div class="tab-pane active" id="all">
                     <ul class="row">
                       <?php
                         $i = 1;
                       ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li class="col-xl-3 col-lg-4 col-sm-6 col-12 <?php echo e(($i > 4) ? 'moreload' : ''); ?>">
                             <div class="product-wrap">
                                 <div class="product-img">
                                     <img src="<?php echo e(asset('uploads/product_thumbnail_image')); ?>/<?php echo e($product->product_thumbnail_image); ?>" alt="">
                                     <div class="product-icon flex-style">
                                         <ul>
                                             <li><a data-toggle="modal" data-target="#exampleModalCenter" href="javascript:void(0);"><i class="fa fa-eye"></i></a></li>
                                             <li><a href="wishlist.html"><i class="fa fa-heart"></i></a></li>
                                             <li><a href="cart.html"><i class="fa fa-shopping-bag"></i></a></li>
                                         </ul>
                                     </div>
                                 </div>
                                 <div class="product-content">
                                     <h3><a href="<?php echo e(route('products.show', $product->product_slug)); ?>"><?php echo e($product->product_name); ?></a></h3>
                                     <p class="pull-left">$<?php echo e($product->product_price); ?>


                                     </p>
                                     <ul class="pull-right d-flex">
                                         <li><i class="fa fa-star"></i></li>
                                         <li><i class="fa fa-star"></i></li>
                                         <li><i class="fa fa-star"></i></li>
                                         <li><i class="fa fa-star"></i></li>
                                         <li><i class="fa fa-star-half-o"></i></li>
                                     </ul>
                                 </div>
                             </div>
                         </li>
                         <?php
                           $i++;
                         ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <li class="col-12 text-center">
                             <a class="loadmore-btn" href="javascript:void(0);">Load More</a>
                         </li>
                     </ul>
                 </div>
                 <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="tab-pane" id="category_<?php echo e($category->id); ?>">
                       <ul class="row">
                          <?php $__currentLoopData = $category->get_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li class="col-xl-3 col-lg-4 col-sm-6 col-12">
                               <div class="product-wrap">
                                   <div class="product-img">
                                       <img src="<?php echo e(asset('uploads/product_thumbnail_image')); ?>/<?php echo e($pro->product_thumbnail_image); ?>" alt="">
                                       <div class="product-icon flex-style">
                                           <ul>
                                               <li><a data-toggle="modal" data-target="#exampleModalCenter" href="javascript:void(0);"><i class="fa fa-eye"></i></a></li>
                                               <li><a href="wishlist.html"><i class="fa fa-heart"></i></a></li>
                                               <li><a href="cart.html"><i class="fa fa-shopping-bag"></i></a></li>
                                           </ul>
                                       </div>
                                   </div>
                                   <div class="product-content">
                                       <h3><a href="<?php echo e(route('products.show', $pro->product_slug)); ?>"><?php echo e($pro->product_name); ?></a></h3>
                                       <p class="pull-left">$<?php echo e($pro->product_price); ?>


                                       </p>
                                       <ul class="pull-right d-flex">
                                           <li><i class="fa fa-star"></i></li>
                                           <li><i class="fa fa-star"></i></li>
                                           <li><i class="fa fa-star"></i></li>
                                           <li><i class="fa fa-star"></i></li>
                                           <li><i class="fa fa-star-half-o"></i></li>
                                       </ul>
                                   </div>
                               </div>
                             </li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </ul>
                   </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
         </div>
     </div>
     <!-- product-area end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\Test Projects\water\resources\views/frontend/shop.blade.php ENDPATH**/ ?>