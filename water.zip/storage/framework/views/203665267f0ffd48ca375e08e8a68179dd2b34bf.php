
<?php $__env->startSection('title'); ?>
  Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-category'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav'); ?>
  <nav class="breadcrumb sl-breadcrumb">
    <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>">Home</a>
    <span class="breadcrumb-item active">Category</span>
  </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-lg-8 m-auto">
        <div class="card">
          <div class="card-header">
            <h5 class="text-center">Edit Category</h5>
          </div>
          <div class="card-body">
            <form class="form-group" action="<?php echo e(route('category.update', $category->id)); ?>" method="post" enctype="multipart/form-data">
              <?php echo e(method_field('PUT')); ?>

              <?php echo csrf_field(); ?>
              <div class="py-3">
                <input class="form-control" type="text" name="category_name" value="<?php echo e($category->category_name); ?>">
              </div>
              <div class="py-3">
                <img class="text-center my-4" src="<?php echo e(asset('uploads/category')); ?>/<?php echo e($category->category_image); ?>" alt="" width="100">
                <input class="form-control" type="file" name="category_image">
              </div>
              <div class="py-3">
                <button type="submit" class="btn btn-primary">Update Category</button>
              </div>
              <?php if(session('hobena')): ?>
                <div class="alert alert-danger">
                  <?php echo e(session('hobena')); ?>

                </div>
              <?php endif; ?>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\water\resources\views/category/edit.blade.php ENDPATH**/ ?>