

<?php $__env->startSection('title'); ?>
  Water - Cart
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- .breadcumb-area start -->
   <div class="breadcumb-area bg-img-4 ptb-100">
       <div class="container">
           <div class="row">
               <div class="col-12">
                   <div class="breadcumb-wrap text-center">
                       <h2>Shopping Cart</h2>
                       <ul>
                           <li><a href="index.html">Home</a></li>
                           <li><span>Shopping Cart</span></li>
                       </ul>
                   </div>
               </div>
           </div>
       </div>
   </div>
   <!-- .breadcumb-area end -->
   <!-- cart-area start -->
   <div class="cart-area ptb-100">
       <div class="container">
           <div class="row">
               <div class="col-12">
                   <form action="<?php echo e(route('cart.custom.update')); ?>" method="post">
                     <?php echo csrf_field(); ?>
                       <table class="table-responsive cart-wrap">
                         <?php if(session('success')): ?>
                           <div class="alert alert-success" role="alert">
                               <?php echo e(session('success')); ?>

                           </div>
                         <?php endif; ?>
                         <?php if($errors->all()): ?>
                             <div class="alert alert-danger">
                                 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <li><?php echo e($error); ?></li>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </div>
                         <?php endif; ?>
                           <thead>
                               <tr>
                                   <th class="images">Image</th>
                                   <th class="product">Product</th>
                                   <th class="ptice">Price</th>
                                   <th class="quantity">Quantity</th>
                                   <th class="total">Total</th>
                                   <th class="remove">Remove</th>
                               </tr>
                           </thead>
                           <tbody>
                               <?php $__currentLoopData = cartItems(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <tr>
                                     <td class="images"><img src="<?php echo e(asset('uploads/product_thumbnail_image')); ?>/<?php echo e($item->get_product->product_thumbnail_image); ?>" alt=""></td>
                                     <td class="product"><a href="<?php echo e(route('products.show', $item->get_product->product_slug)); ?>"><?php echo e($item->get_product->product_name); ?></a></td>
                                     <td class="ptice">$<?php echo e($item->get_product->product_price); ?></td>
                                     <input type="hidden" name="id[]" value="<?php echo e($item->id); ?>">
                                     <td class="quantity cart-plus-minus">
                                         <input name="cart_amount[]" type="text" value="<?php echo e($item->cart_amount); ?>"/>
                                     </td>
                                     <td class="total">$<?php echo e($item->cart_amount * $item->get_product->product_price); ?></td>
                                     <td class="remove">
                                       <a href="<?php echo e(route('cart.delete', $item->id)); ?>"><i class="fa fa-times"></i></a>
                                     </td>
                                 </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tbody>
                       </table>
                       <div class="row mt-60">
                           <div class="col-xl-4 col-lg-5 col-md-6 ">
                               <div class="cartcupon-wrap">
                                   <ul class="d-flex">
                                       <li>
                                           <button type="submit">Update Cart</button>
                                         </form>
                                       </li>
                                       <li><a href="<?php echo e(url('/')); ?>">Continue Shopping</a></li>
                                   </ul>
                                   <h3>Cupon</h3>
                                   <p>Enter Your Cupon Code if You Have One</p>
                                   <div class="cupon-wrap">
                                       <input type="text" placeholder="Cupon Code" id="couponName" value="<?php echo e($coupon_name ?? ""); ?>">
                                       <button type="button" id="applyCoupon">Apply Cupon</button>
                                   </div>
                               </div>
                           </div>
                           <div class="col-xl-3 offset-xl-5 col-lg-4 offset-lg-3 col-md-6">
                               <div class="cart-total text-right">
                                   <h3>Cart Totals</h3>
                                   <ul>
                                       <li><span class="pull-left">Subtotal </span>$<?php echo e(cartTotal()); ?></li>
                                       <?php if(isset($coupon_discount)): ?>
                                       <li><span class="pull-left">Discount </span><?php echo e($coupon_discount->discount); ?>%</li>
                                       <li><span class="pull-left">Total </span>$<?php echo e($total = cartTotal() - ($coupon_discount->discount / 100) * cartTotal()); ?></li>
                                       <?php else: ?> 
                                       <li><span class="pull-left"> Total </span> $<?php echo e(cartTotal()); ?></li>
                                       <?php endif; ?>
                                      
                                   </ul>
                                   <form action="<?php echo e(route('checkout.index')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                
                                    <input type="hidden" value="<?php echo e($coupon_discount->coupon_name ?? ""); ?>" name="coupon_name">
                                    <input type="hidden" value="<?php echo e($total ?? ""); ?>" name="total">
                             
                                    <button class="btn btn-danger" type="submit">Proceed to Checkout</button>
                                   </form>
                               </div>
                           </div>
                       </div>
               </div>
           </div>
       </div>
   </div>
   <!-- cart-area end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <script>
     $(document).ready(function(){
       $('#applyCoupon').click(function(){
          var coupon_name = $('#couponName').val();
          window.location.href = "<?php echo e(url('/cart')); ?>" + "/" + coupon_name
       });
     });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\Test Projects\water\resources\views/frontend/cart.blade.php ENDPATH**/ ?>