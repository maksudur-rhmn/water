
<?php $__env->startSection('title'); ?>
  Coupon
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-coupon'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav'); ?>
  <nav class="breadcrumb sl-breadcrumb">
    <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>">Home</a>
    <span class="breadcrumb-item active">Coupon</span>
  </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-lg-8 m-auto">
        <div class="d-flex float-right mb-3">
          <a href="<?php echo e(route('coupon.create')); ?>" class="btn btn-success">Add Coupon</a>
        </div>
        <table class="table table-striped">
          <tr>
            <th>SL</th>
            <th>Coupon Name</th>
            <th>Coupon Discount</th>
            <th>Valid Till</th>
            <th>Created at</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
          <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->index +1); ?></td>
            <td><?php echo e($coupon->coupon_name); ?></td>
            <td><?php echo e($coupon->discount); ?> %</td>
            <td><?php echo e($coupon->valid_till); ?></td>
            <td><?php echo e($coupon->created_at->format('Y-m-d')); ?></td>
            <td>
              <?php if($coupon->valid_till >= \Carbon\Carbon::now()->format('Y-m-d')): ?>
                <span class="badge badge-success"><?php echo e(\Carbon\Carbon::parse($coupon->valid_till)->diffInDays(\Carbon\Carbon::now()->format('Y-m-d'))); ?> Days left</span>
              <?php else: ?>
                <span class="badge badge-danger">Expired</span>
              <?php endif; ?>
            </td>
            <td>
              <a href="<?php echo e(route('coupon.edit', $coupon->id)); ?>" class="btn btn-warning">Edit</a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\Test Projects\water\resources\views/coupon/index.blade.php ENDPATH**/ ?>