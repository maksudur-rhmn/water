<?php $__env->startSection('title'); ?>
  Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-home'); ?>
  active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav'); ?>
  <nav class="breadcrumb sl-breadcrumb">
    <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>">Home</a>
    
  </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
           <div class="card" style="width: 18rem;">
               <div class="card-header">
                   <?php echo e(Auth::user()->name); ?>

               </div>
               <div class="card-body">
                   <h5 >Welcome To Customer dashboard</h5>

           </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\water\resources\views/customer/index.blade.php ENDPATH**/ ?>