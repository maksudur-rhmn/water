



 Your new password is : <?php echo e($new_password); ?>;
<?php /**PATH G:\Laravel Project\water\resources\views/mailer/changepassword.blade.php ENDPATH**/ ?>