

<?php $__env->startSection('title'); ?>
  Water - Ecommerce Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('active-home'); ?>
  active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- slider-area start -->
    <?php echo $__env->make('frontend.includes.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- slider-area end -->
    <!-- category-area start -->
    <?php if(session('success')): ?>
      <div class="alert alert-success">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>
    <?php echo $__env->make('frontend.includes.category', ['categories' => $categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- category-area end -->
    <!-- start count-down-section -->
    <?php echo $__env->make('frontend.includes.counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end count-down-section -->
    <!-- bestseller-area start -->
    <?php echo $__env->make('frontend.includes.best_seller', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- best seller-area end -->
    <!-- product-area start -->
    <?php echo $__env->make('frontend.includes.products', ['products' => $products], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- product-area end -->
    <!-- testmonial-area start -->
    <?php echo $__env->make('frontend.includes.testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- testmonial-area end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\Test Projects\water\resources\views/frontend/index.blade.php ENDPATH**/ ?>