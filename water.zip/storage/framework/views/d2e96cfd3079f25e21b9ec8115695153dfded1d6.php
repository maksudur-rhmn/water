<?php $__env->startSection('title'); ?>
  Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-home'); ?>
  active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav'); ?>
  <nav class="breadcrumb sl-breadcrumb">
    <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>">Home</a>
    
  </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-lg-6 py-3">
      <div class="card">
        <div class="card-header">
          <h5>Seven Days Sale</h5>
        </div>
        <div class="card-body">
           <?php echo e($SevenDaysSaleChart->container()); ?>

           <?php echo e($SevenDaysSaleChart->script()); ?>

        </div>
      </div>
    </div>
    <div class="col-lg-6 py-3">
      <div class="card">
        <div class="card-header">
          <h5>Payment methods</h5>
        </div>
        <div class="card-body">
           <?php echo e($payment_method->container()); ?>

           <?php echo e($payment_method->script()); ?>

        </div>
      </div>
    </div>
  </div>
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Total User :  <?php echo e($total_user); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table table-striped">
                      <tr>
                        <th>SL</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Created at</th>
                        <th>Updated at</th>
                      </tr>
                      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($loop-> index + 1); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                        <?php if($user->updated_at): ?>
                          <td><?php echo e($user->updated_at->diffForHumans()); ?></td>
                        <?php else: ?>
                          <td>--</td>
                        <?php endif; ?>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\Test Projects\water\resources\views/home.blade.php ENDPATH**/ ?>