
<?php $__env->startSection('title'); ?>
  Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-category'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav'); ?>
  <nav class="breadcrumb sl-breadcrumb">
    <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>">Home</a>
    <span class="breadcrumb-item active">Category</span>
  </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

   <div class="container">
     <div class="row">
       <div class="col-lg-4">
         <div class="card">
           <div class="card-header">
             <h5 class="text-center"><?php echo e((isset($category)) ? 'Edit Category' : 'Add Category'); ?></h5>
           </div>
           <div class="card-body">
             <form class="form-group" action="<?php echo e(route('category.store')); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>
               <div class="py-3">
                 <input class="form-control" type="text" name="category_name" placeholder="Enter Category">
               </div>
               <div class="py-3">
                 <input class="form-control" type="file" name="category_image">
               </div>
               <div class="py-3">
                 <button type="submit" class="btn btn-primary">Add Category</button>
               </div>
             </form>
         </div> 
         </div>
       </div>
       <div class="col-lg-8">
         <div class="card-header">
           <h5 class="text-center">All Categories</h5>
         </div>
         <div class="card-body">
              <table class="table table-dark table-striped">
                <tr>
                  <th>SL</th>
                  <th>Category Name</th>
                  <th>Added By</th>
                  <th>Category Image</th>
                  <th>Created at</th>
                  <th>Updated at</th>
                  <th>Action</th>
                  <th></th>
                </tr>
                 <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                     <td><?php echo e($loop-> index + 1); ?></td>
                     <td><?php echo e($category->category_name); ?></td>
                     <td><?php echo e($category->relationBetweenCategory->name); ?></td>
                     <td>
                       <img src="<?php echo e(asset('uploads/category')); ?>/<?php echo e($category->category_image); ?>" alt="not found" width="50">
                     </td>
                      
                     <td><?php echo e($category->created_at->diffForHumans()); ?></td>
                     <td>--</td>
                     <td>
                       <a href="<?php echo e(route('category.edit', $category->id)); ?>" class="btn btn-info">Edit</a>
                     </td>
                     <td>
                          <button type="button" class="btn btn-danger" onclick="deleteHandler(<?php echo e($category->id); ?>)">Delete</button>
                     </td>
                   </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
              <!-- Modal -->
              <form action="" method="post" id="forId">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('DELETE')); ?>

                <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                      Are you sure?
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">No, Go back</button>
                        <button type="submit" class="btn btn-danger">Yes, Delete</button>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
           </div>
         </div>
       </div>
     </div>
   </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script>
      function deleteHandler(id)
    {
      var form = document.getElementById('forId')
      form.action = 'category/' + id
      $('#deleteModal').modal('show')

    }
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\water\resources\views/category/index.blade.php ENDPATH**/ ?>