<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <script src="https://www.paypal.com/sdk/js?client-id=AUQJ9L3072dw8fX2xODkXvaGgLgkhDXpk8kU15k6ri2Lp9iCG2NL0ZkFiHn2aUfkR7FdilPxM16wQDBS"></script>
    <script>paypal.Buttons().render('body');</script>
</body>
</html><?php /**PATH G:\Laravel Project\Test Projects\water\resources\views/paypal.blade.php ENDPATH**/ ?>