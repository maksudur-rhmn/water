

<?php $__env->startSection('content'); ?>
<div class="product-area">
    <div class="fluid-container">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <h2>Our Latest Product</h2>
                    <img src="assets/images/section-title.png" alt="">
                </div>
            </div>
        </div>
        <ul class="row">
          <?php
            $flag = 1;
          ?>
          <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="col-xl-3 col-lg-4 col-sm-6 col-12 <?php echo e(($flag > 4) ? 'moreload' : ''); ?>">
                <div class="product-wrap">
                    <div class="product-img">
                        <span>Sale</span>
                        <img src="<?php echo e(asset('uploads/product_thumbnail_image')); ?>/<?php echo e($product->product_thumbnail_image); ?>" alt="">
                        <div class="product-icon flex-style">
                            <ul>
                                <li><a data-toggle="modal" data-target="#exampleModalCenter" href="javascript:void(0);"><i class="fa fa-eye"></i></a></li>
                                <li><a href="wishlist.html"><i class="fa fa-heart"></i></a></li>
                                <li><a href="cart.html"><i class="fa fa-shopping-bag"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="product-content">
                        <h3><a href="<?php echo e(route('products.show', $product->product_slug)); ?>"><?php echo e($product->product_name); ?></a></h3>
                        <p class="pull-left">$<?php echo e($product->product_price); ?>


                        </p>
                        <ul class="pull-right d-flex">
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star"></i></li>
                            <li><i class="fa fa-star-half-o"></i></li>
                        </ul>
                    </div>
                </div>
            </li>
            <?php
              $flag++;
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
             <h5>There is no products that matches your search criteria. Please try again </h5>
          <?php endif; ?>
            <li class="col-12 text-center">
                <a class="loadmore-btn" href="javascript:void(0);">Load More</a>
            </li>
        </ul>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\Test Projects\water\resources\views/frontend/search.blade.php ENDPATH**/ ?>