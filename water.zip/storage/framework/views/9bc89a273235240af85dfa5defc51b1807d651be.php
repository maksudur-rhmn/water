

<?php $__env->startSection('title'); ?>
  Water - Checkout
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
       <!-- .breadcumb-area start -->
       <div class="breadcumb-area bg-img-4 ptb-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcumb-wrap text-center">
                        <h2>Checkout</h2>
                        <ul>
                            <li><a href="index.html">Home</a></li>
                            <li><span>Checkout</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- .breadcumb-area end -->
    <!-- checkout-area start -->
    <div class="checkout-area ptb-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <?php if($errors->all()): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <div class="checkout-form form-style">
                        <h3>Billing Details</h3>
                            <form id="paypal_sub" action="<?php echo e(route('order.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-12">
                                        <p>Full Name</p>
                                        <input type="text" name="full_name" value="<?php echo e(Auth::user()->name); ?>">
                                    </div>
                                    <div class="col-sm-6 col-12">
                                        <p>Email Address *</p>
                                        <input type="email" name="email" value="<?php echo e(Auth::user()->email); ?>">
                                    </div>
                                    <div class="col-sm-6 col-12">
                                        <p>Phone No. *</p>
                                        <input type="text" name="phone_number" placeholder="Areacode : (+123) Number : (123-456)">
                                    </div>
                                    <div class="col-12">
                                        <select name="country_id" id="country_id">
                                            <option value="">--Select Your Country</option>
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <select name="city_id" id="city_list">
                                            <option value="">--Select Your City</option>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <p>Your Address *</p>
                                        <input type="text" name="address">
                                    </div>
                                    <div class="col-12">
                                        <p>Order Notes </p>
                                        <textarea name="notes" placeholder="Notes about Your Order, e.g.Special Note for Delivery" name="notes"></textarea>
                                    </div>
                                </div>
                           
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="order-area">
                            <h3>Your Order</h3>
                            <ul class="total-cost">
                                <?php $__currentLoopData = cartItems(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($item->get_product->product_name); ?> Qt. <?php echo e($item->cart_amount); ?> <span class="pull-right">$<?php echo e($item->get_product->product_price * $item->cart_amount); ?></span></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li>Subtotal <span class="pull-right"><strong>$<?php echo e(cartTotal()); ?></strong></span></li>
                                <li>Coupon <span class="pull-right"><?php echo e($coupon_name ?? "No coupon used"); ?></span></li>
                                <li>Total<span class="pull-right">$<?php echo e($total ?? cartTotal()); ?></span></li>
                            </ul>
                            <ul class="payment-method">
                                <li>
                                    <input value="3" id="paypal" type="radio" name="payment_method">
                                    <label for="paypal">Paypal</label>
                                </li>
                                <li>
                                    <input value="2" id="card" type="radio" name="payment_method">
                                    <label for="card">Credit Card</label>
                                </li>
                                <li>
                                    <input value="1" id="delivery" type="radio" name="payment_method" checked>
                                    <label for="delivery">Cash on Delivery</label>
                                </li>
                            </ul>
                            <input name="sub_total" type="hidden" value="<?php echo e(cartTotal()); ?>">
                            <input name="coupon_name" type="hidden" value="<?php echo e($coupon_name); ?>">
                            <input name="total" type="hidden" value="<?php echo e($total ?? cartTotal()); ?>">
                            <button type="submit">Place Order</button>
                            </form>
                            <div class="btn"></div>

                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- checkout-area end -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

 
    <script>
        $(document).ready(function(){
           $("#country_id").change(function(){
           var country_id = $('#country_id').val();
         
            // Ajax Default Code Start 

            $.ajaxSetup({
           headers: {
               'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });        

            // Ajax Default Code Ends 

            $.ajax({
               type:'POST',
               url:'/citylist',
               data:{country_id:country_id},
               success:function(data)
               {
                 $("#city_list").html(data);
               }
           });
            
           });
        });
    </script>
     
  <script>
    $(document).ready(function(){
        $("#paypal").click(function(){
            var form = document.getElementById('paypal_sub')
            form.action = "<?php echo e(route('create-payment')); ?>"
            console.log(form)
        })
        $("#delivery").unbind("click", process_click);
        $("#card").unbind("click", process_click);
    })

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\Test Projects\water\resources\views/frontend/checkout.blade.php ENDPATH**/ ?>