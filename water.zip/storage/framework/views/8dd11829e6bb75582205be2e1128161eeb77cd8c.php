

<?php $__env->startSection('title'); ?>
  Frequently Asked Questions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active-faq'); ?>
  active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav'); ?>
  <nav class="breadcrumb sl-breadcrumb">
    <a class="breadcrumb-item" href="<?php echo e(route('home')); ?>">Home</a>
    <a class="breadcrumb-item" href="<?php echo e(route('faq_index')); ?>">Faq</a>
    <span class="breadcrumb-item active"><?php echo e($faq->faq_question); ?></span>
  </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

 <div class="container">
   <div class="row">
     <div class="col-lg-8 m-auto">
      <div class="card">
        <div class="card-header">
          <h5 class="text-center">Edit Faq</h5>
        </div>
        <div class="card-body">
          <form class="form-group" action="<?php echo e(url('/faq/update')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="py-3">
              <input type="hidden" name="id" value="<?php echo e($faq->id); ?>">
              <input class="form-control" type="text" name="faq_question" value="<?php echo e($faq->faq_question); ?>">
            </div>
            <div class="py-3">
              <input class="form-control" type="text" name="faq_answer" value="<?php echo e($faq->faq_answer); ?>">
            </div>
            <div class="py-3">
              <button type="submit" class="btn btn-primary">Update</button>
            </div>
          </form>
        </div>
      </div>
     </div>
   </div>
 </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Laravel Project\water\resources\views/faq/edit.blade.php ENDPATH**/ ?>