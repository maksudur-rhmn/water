<div class="featured-area featured-area2">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="featured-active2 owl-carousel next-prev-style">
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="featured-wrap">
                        <div class="featured-img">
                            <img src="<?php echo e(asset('uploads/category')); ?>/<?php echo e($category->category_image); ?>" alt="not found">
                            <div class="featured-content">
                                <a href="shop.html"><?php echo e($category->category_name); ?></a>
                            </div>
                        </div>
                      </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH G:\Laravel Project\water\resources\views/frontend/includes/category.blade.php ENDPATH**/ ?>