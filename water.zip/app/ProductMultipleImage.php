<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductMultipleImage extends Model
{
    //
}
